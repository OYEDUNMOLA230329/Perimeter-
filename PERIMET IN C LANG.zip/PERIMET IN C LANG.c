#include <stdio.h>
#include <math.h>


float area_of_triangle(float base, float height) {
	return 0.5 * base * height;
}
float area_of_circle(float radius){
	return M_PI * radius * radius;
}
float perimeter_of_square(float side) {
	return 4 *side;
}

int main(){
	float base, height;
	float radius;
	float side;
	
	printf("Enter the area of triangle");
	scanf("%f, %f" , &base,height);
	
	printf("Area of the triangle: %.2f\n" , area_of_triangle(base, height));
		
	printf("Enter the area of circle");
	scanf("%f", &radius);
	
	printf("Area of the circle: %.2f\n" , area_of_circle(radius));
		
	printf("Entre the perimeter of square");
	scanf("%f", &side);
	
	printf("Perimeter of Square: %.2f\n" , perimeter_of_square(side));

   return 0;
}